## Packages
xlsx | For exporting attendance logs to Excel
framer-motion | For beautiful page transitions and micro-interactions

## Notes
- Geolocation API requires a secure context (HTTPS) or localhost.
- Uses session-based auth via `/api/auth/me`.
